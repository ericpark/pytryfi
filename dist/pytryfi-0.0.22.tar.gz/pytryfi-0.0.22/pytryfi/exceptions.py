class Error(Exception):
    """base exception class"""

class TryFiError(Error):
    """Generic error for TryFi"""
    